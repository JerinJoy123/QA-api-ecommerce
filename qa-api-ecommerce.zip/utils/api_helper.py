def format_url(base_url, endpoint):
    return f"{base_url}/{endpoint.strip('/')}"
